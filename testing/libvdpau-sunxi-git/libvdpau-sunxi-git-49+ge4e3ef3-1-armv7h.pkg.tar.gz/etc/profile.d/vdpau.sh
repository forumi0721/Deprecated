export VDPAU_DRIVER=sunxi
export VDPAU_OSD=1
