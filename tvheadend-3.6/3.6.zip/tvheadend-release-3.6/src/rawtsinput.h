

void rawts_init(const char *filename);

