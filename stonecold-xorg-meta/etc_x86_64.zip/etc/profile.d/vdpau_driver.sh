export VDPAU_DRIVER=va_gl
