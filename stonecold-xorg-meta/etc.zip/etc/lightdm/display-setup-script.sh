#!/bin/sh

xrandr -s 1280x1024

if [ ! -z "$(which x0vncserver)" ]; then
	x0vncserver -display :0 -SecurityTypes=VncAuth -PasswordFile=/etc/lightdm/vncpasswd &
fi
