#!/bin/sh

#Variable
MC2XML_HOME="/var/mc2xml"
OUTPUT=xmltv.xml

## Function - Download
function FuncDownload {
	local target="$1"
	local dat="mc2xml_${target}.dat"
	local ren="mc2xml_${target}.ren"
	local chl="mc2xml_${target}.chl"
	local xml="xmltv_${target}.xml"
	local option=

	if [ ! -e "${dat}" ]; then
		return 1
	fi

	option=("-D ${dat}")
	if [ -e "${ren}" ]; then
		option+=("-R ${ren}")
	fi
	if [ -e "${chl}" ]; then
		option+=("-C ${chl}")
	fi
	option+=("-o ${xml}")

	for cnt in {1..10}
	do
		echo "Start Download ${target} - ${cnt}"
		mc2xml ${option[@]}
		case $? in
			"0")
				break
				;;
			"1")
				if [ -e "${xml}.gz" ]; then
					gzip -dc "${xml}.gz" > "${xml}"
				fi
				break
				;;
			*)
				if [ -e "${xml}" ]; then
					break
				fi
				;;
		esac
	done
	if [ ! -e "${xml}" ]; then
		if [ -e "${xml}.gz" ]; then
			gzip -dc "${xml}.gz" > "${xml}"
		else
			echo "Download failed"
		fi
	fi
}

## Function - Merge
function FuncMerge {
	#Header
	cat << EOF > xmltv.xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE tv SYSTEM "xmltv.dtd">

<tv source-info-name="EPGI" generator-info-name="mc2xml" generator-info-url="mailto:mc2xml@gmail.com">
EOF

	#channel
	for target in ${TARGET[@]}
	do
		if [ ! -e "xmltv_${target}.xml" ]; then
			continue
		fi
		local start=$(grep --line-number '<channel id=' xmltv_${target}.xml | head -n 1 | cut -d ':' -f 1)
		local end=$(grep --line-number '</channel>' xmltv_${target}.xml | tail -n 1 | cut -d ':' -f 1)

		if [ -z "${start}" ] || [ -z "${end}" ]; then
			continue
		fi

		sed -n "${start},${end}p" xmltv_${target}.xml >> ${OUTPUT}
	done

	#programme
	for target in ${TARGET[@]}
	do
		if [ ! -e "xmltv_${target}.xml" ]; then
			continue
		fi
		local start=$(grep --line-number '<programme start=' xmltv_${target}.xml | head -n 1 | cut -d ':' -f 1)
		local end=$(grep --line-number '</programme>' xmltv_${target}.xml | tail -n 1 | cut -d ':' -f 1)

		if [ -z "${start}" ] || [ -z "${end}" ]; then
			continue
		fi

		sed -n "${start},${end}p" xmltv_${target}.xml >> ${OUTPUT}
	done

	#Footer
	cat << EOF >> xmltv.xml
</tv>
EOF
}

##Main
if [ ! -e "${MC2XML_HOME}" ]; then
	echo "Cannot found ${MC2XML_HOME}"
	exit 1
fi
if [ -z "$(which mc2xml)" ]; then
	echo "Cannot found mc2xml"
	exit 1
fi
if [ -z "$(which gzip)" ]; then
	echo "Cannot found gzip"
	exit 1
fi

pushd . &> /dev/null

cd "${MC2XML_HOME}"
TARGET=($(ls /var/mc2xml/*.dat | sed 's/^.*mc2xml_\(.*\)\.dat$/\1/g'))
if [ "${#TARGET[@]}" = "0" ]; then
	echo "Cannot found ${MC2XML_HOME}/*.dat"
	exit 1
fi

#Download

echo "Start Download"
for target in ${TARGET[@]}
do
	FuncDownload ${target}
done
echo "Done"
echo

echo "Start Merge"
if [ "${#TARGET[@]}" = "1" ]; then
	if [ -e "xmltv_${TARGET}.xml" ]; then
		rm -rf xmltv_${TARGET}.xml.gz xmltv.xml.gz
		gzip -9 xmltv_${TARGET}.xml
		cp xmltv_${TARGET}.xml.gz xmltv.xml.gz
	fi
else
	FuncMerge
	for target in ${TARGET[@]}
	do
		if [ -e "xmltv_${target}.xml" ]; then
			rm -rf xmltv_${target}.xml.gz
			gzip -9 xmltv_${target}.xml
		fi
	done
	if [ -e "xmltv.xml" ]; then
		rm -rf xmltv.xml.gz
		gzip -9 xmltv.xml
	fi
fi
echo "Done"
echo

popd &> /dev/null
