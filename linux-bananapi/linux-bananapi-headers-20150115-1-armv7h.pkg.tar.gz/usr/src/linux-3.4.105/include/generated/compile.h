/* This file is auto generated, version 3 */
/* SMP PREEMPT */
#define UTS_MACHINE "arm"
#define UTS_VERSION "#3 SMP PREEMPT Wed Jan 14 01:55:20 KST 2015"
#define LINUX_COMPILE_BY "forumi0721"
#define LINUX_COMPILE_HOST "StoneColdPC.local"
#define LINUX_COMPILER "gcc version 4.9.1 (crosstool-NG 1.20.0) "
