/* This file is auto generated, version 2 */
/* SMP PREEMPT */
#define UTS_MACHINE "arm"
#define UTS_VERSION "#2 SMP PREEMPT Mon Jan 19 09:30:31 KST 2015"
#define LINUX_COMPILE_BY "forumi0721"
#define LINUX_COMPILE_HOST "StoneColdPC.local"
#define LINUX_COMPILER "gcc version 4.9.1 (crosstool-NG 1.20.0) "
